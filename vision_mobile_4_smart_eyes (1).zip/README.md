# VISION Mobile 4.0 — Smart Eyes

A free, mobile-first browser prototype for Android. It uses the phone camera and the COCO-SSD object-detection model to detect common objects, draw boxes, estimate rough visible color and frame position, and show general category information. It can read details aloud and export a JSON report.

## Free hosting on GitHub Pages

1. Download and extract this ZIP.
2. Sign in to GitHub and create a **public** repository named `vision-mobile`.
3. Upload `index.html` from this package to the repository root and commit the file.
4. Open **Settings → Pages**.
5. Under build/deployment, choose **Deploy from a branch**, select branch `main` and folder `/(root)`, then save.
6. Wait for the Pages URL, usually `https://YOUR-USERNAME.github.io/vision-mobile/`.
7. Open that HTTPS URL in Chrome on Android and allow camera permission.

## What it includes

- Live rear/front camera switching
- Free COCO-SSD detection of common categories (model is downloaded from a public CDN on first use)
- On-screen detection boxes, confidence, and selectable object list
- Rough pixel-based color estimate, frame position, and approximate frame coverage
- General facts/history entries for selected common categories
- Read selected details aloud using browser text-to-speech when available
- Export a selected-object JSON report, snapshot, pause/resume, zoom, full screen
- No account, paid API, or video upload to this app

## Important limits

- First use requires internet to load TensorFlow.js and the COCO-SSD model. After that, caching behavior depends on the browser; offline operation is not guaranteed.
- Camera requires a secure context (HTTPS or supported localhost). A downloaded `file://` page may not be allowed to access the camera.
- Detection is limited to the classes supported by COCO-SSD. It is not a general-purpose AI that recognizes every object.
- Color and position are estimates. Lighting, shadows, occlusion, and camera angle affect them.
- General facts/history are built-in category-level information, not live web research or facts about the specific individual object. A dog image cannot reliably reveal its exact breed, name, age, health, or personal history.
- Camera processing happens in the browser. External CDN requests download the software/model, but this app does not upload camera frames to a server.
- This is a website prototype, not a native Android APK.

## Troubleshooting

- If the camera is denied, open the Pages HTTPS URL in Chrome, tap the site icon/settings near the address bar, and set Camera to Allow. Also check Android Settings → Apps → Chrome → Permissions → Camera and the system-wide Camera access toggle.
- If the model does not load, check internet and reload. Some networks or browser content blockers may block the CDN.
- Keep the phone steady, use reasonable light, and point at one clear object for better results.
